# ColourApp
Fast way to get apps.


## Modules

### unpack.py

Unpackes ColourApp to `./unpacker_result`.

### validate.py

Validates `app_data.json`. Validation of core script coming soon.

### copy.py

Copies validated ColourApp contents to `/apps/...`
